<?php

$dbHost = "localhost";
$dbUser = "root";
$dbPass = "";
$dbName = "qrcode";

$db = new mysqli($dbHost,$dbUser,$dbPass,$dbName);





?>